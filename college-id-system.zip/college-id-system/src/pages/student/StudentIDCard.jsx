import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';

export default function StudentIDCard() {
  const { currentUser, getStudentById } = useApp();
  const student = getStudentById(currentUser.id);
  const cardRef = useRef();

  const handlePrint = () => window.print();

  const validUntil = `May 2026`;

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">My ID Card</h1>
        <p className="page-subtitle">Your digital college ID card</p>
      </div>

      <div style={{ display: 'flex', gap: 32, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* ID Card Preview */}
        <div ref={cardRef}>
          <div className="id-card" style={{ width: 340 }}>
            {/* Header */}
            <div className="id-card-header">
              <div style={{ fontSize: 13, fontWeight: 800, color: '#fff', letterSpacing: 0.5 }}>
                🎓 COLLEGE OF ENGINEERING & TECHNOLOGY
              </div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>
                Hyderabad, Telangana · NAAC Accredited
              </div>
              <div style={{
                marginTop: 10, background: 'rgba(255,255,255,0.15)',
                borderRadius: 4, padding: '3px 10px', display: 'inline-block',
                fontSize: 10, fontWeight: 700, color: '#fff', letterSpacing: 1, textTransform: 'uppercase',
              }}>
                Student Identity Card
              </div>
            </div>

            {/* Body */}
            <div className="id-card-body">
              {/* Photo */}
              <div style={{
                width: 75, height: 90, flexShrink: 0,
                background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 28, color: '#fff', fontWeight: 800,
                border: '2px solid #1e3a8a',
              }}>
                {student?.name?.charAt(0) || 'S'}
              </div>

              {/* Info */}
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#1e293b', lineHeight: 1.2 }}>
                  {student?.name || currentUser.name}
                </div>
                <div style={{ fontSize: 10, color: '#64748b', marginBottom: 8, marginTop: 2 }}>
                  {student?.course}
                </div>

                {[
                  ['Roll No', student?.rollNo || currentUser.id],
                  ['Dept', student?.dept],
                  ['Year', student?.year],
                  ['Phone', student?.phone],
                ].map(([k, v]) => v && (
                  <div key={k} style={{ display: 'flex', gap: 6, marginBottom: 3 }}>
                    <span style={{ fontSize: 9, color: '#94a3b8', minWidth: 40, fontWeight: 600, textTransform: 'uppercase' }}>{k}:</span>
                    <span style={{ fontSize: 10, color: '#334155', fontWeight: 600 }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Barcode placeholder */}
            <div style={{
              background: '#f8fafc',
              padding: '8px 16px',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#475569' }}>
                {'||| |||| | ||| ||||| | ||||'}
                <div style={{ fontSize: 8, marginTop: 1 }}>{student?.rollNo}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 8, color: '#94a3b8' }}>Valid Until</div>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#1e293b' }}>{validUntil}</div>
              </div>
            </div>

            {/* Footer */}
            <div className="id-card-footer">
              <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.6)' }}>
                If found, please return to<br />the college administration
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 8, color: 'rgba(255,255,255,0.5)' }}>Authorized by</div>
                <div style={{ fontSize: 9, color: '#fff', fontWeight: 600 }}>Principal</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions & Info */}
        <div style={{ flex: 1, minWidth: 240 }}>
          <div className="card mb-4">
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Student Details</h3>
            {[
              ['Full Name', student?.name || currentUser.name],
              ['Roll Number', student?.rollNo || currentUser.id],
              ['Course', student?.course],
              ['Department', student?.dept],
              ['Year', student?.year],
              ['Email', student?.email || currentUser.id + '@college.edu'],
              ['Phone', student?.phone],
            ].map(([k, v]) => v && (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '9px 0', borderBottom: '1px solid var(--border)',
                fontSize: 13,
              }}>
                <span style={{ color: 'var(--text3)' }}>{k}</span>
                <span style={{ fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <button className="btn btn-primary btn-lg" onClick={handlePrint} style={{ justifyContent: 'center' }}>
              🖨️ Print ID Card
            </button>
            <div style={{
              padding: '12px 14px', background: 'rgba(245,158,11,0.08)',
              border: '1px solid rgba(245,158,11,0.2)', borderRadius: 9,
              fontSize: 12, color: 'var(--yellow)',
            }}>
              ℹ️ If your ID card is lost, submit a <strong>Replacement ID Card</strong> request from the Request page.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
