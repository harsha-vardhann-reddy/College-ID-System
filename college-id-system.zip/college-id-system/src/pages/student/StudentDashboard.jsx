import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const statusColor = (s) => {
  if (s === 'Approved') return 'badge-green';
  if (s === 'Rejected') return 'badge-red';
  if (s === 'Department Review') return 'badge-purple';
  return 'badge-yellow';
};

export default function StudentDashboard() {
  const { currentUser, getRequestsByStudent, notifications } = useApp();
  const navigate = useNavigate();
  const myRequests = getRequestsByStudent(currentUser.id);
  const myNotifs = notifications.filter(n => n.userId === currentUser.id && !n.read);

  const stats = [
    { label: 'Total Requests', value: myRequests.length, icon: '📄', color: '#3b82f6', bg: 'rgba(59,130,246,0.1)' },
    { label: 'Approved', value: myRequests.filter(r => r.status === 'Approved').length, icon: '✅', color: '#10b981', bg: 'rgba(16,185,129,0.1)' },
    { label: 'Pending', value: myRequests.filter(r => r.status === 'Pending').length, icon: '⏳', color: '#f59e0b', bg: 'rgba(245,158,11,0.1)' },
    { label: 'Notifications', value: myNotifs.length, icon: '🔔', color: '#8b5cf6', bg: 'rgba(139,92,246,0.1)' },
  ];

  const certTypes = [
    { type: 'Bonafide Certificate', icon: '🏫', desc: 'Confirm enrollment status' },
    { type: 'NOC', icon: '📝', desc: 'No Objection Certificate' },
    { type: 'Experience Letter', icon: '💼', desc: 'For job applications' },
    { type: 'Replacement ID Card', icon: '🪪', desc: 'Lost/damaged ID card' },
  ];

  return (
    <div className="page-body">
      {/* Welcome */}
      <div style={{ marginBottom: 28 }}>
        <h1 className="page-title">Welcome back, {currentUser.name.split(' ')[0]}! 👋</h1>
        <p className="page-subtitle">Manage your certificate requests and ID card from here</p>
      </div>

      {/* Stats */}
      <div className="grid-4 mb-6">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon" style={{ background: s.bg }}>
              <span style={{ fontSize: 20 }}>{s.icon}</span>
            </div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 gap-6">
        {/* Quick Actions */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Quick Request</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {certTypes.map(c => (
              <button key={c.type}
                onClick={() => navigate('/student/request', { state: { type: c.type } })}
                style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  background: 'var(--bg3)', border: '1px solid var(--border)',
                  borderRadius: 10, padding: '12px 16px', cursor: 'pointer',
                  textAlign: 'left', transition: 'all 0.18s',
                  color: 'var(--text)',
                }}
                onMouseOver={e => e.currentTarget.style.borderColor = 'var(--accent)'}
                onMouseOut={e => e.currentTarget.style.borderColor = 'var(--border)'}
              >
                <span style={{ fontSize: 22 }}>{c.icon}</span>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{c.type}</div>
                  <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{c.desc}</div>
                </div>
                <span style={{ marginLeft: 'auto', color: 'var(--text3)', fontSize: 16 }}>→</span>
              </button>
            ))}
          </div>
        </div>

        {/* Recent Requests */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Recent Requests</h3>
            <button className="btn btn-secondary btn-sm" onClick={() => navigate('/student/my-requests')}>
              View All
            </button>
          </div>

          {myRequests.length === 0 ? (
            <div className="empty-state">
              <span style={{ fontSize: 40 }}>📭</span>
              <p>No requests yet. Submit your first request!</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {myRequests.slice(0, 4).map(req => (
                <div key={req.id} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '12px', background: 'var(--bg3)', borderRadius: 10,
                  border: '1px solid var(--border)',
                }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 12.5 }}>{req.type}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>
                      Submitted: {req.submittedAt}
                    </div>
                  </div>
                  <span className={`badge ${statusColor(req.status)}`} style={{ marginLeft: 'auto' }}>
                    {req.status}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Notifications preview */}
          {myNotifs.length > 0 && (
            <div style={{ marginTop: 16 }}>
              <h4 style={{ fontSize: 12, color: 'var(--text3)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 8 }}>
                Unread Notifications
              </h4>
              {myNotifs.slice(0, 2).map(n => (
                <div key={n.id} style={{
                  padding: '10px 12px', background: 'rgba(59,130,246,0.08)',
                  border: '1px solid rgba(59,130,246,0.2)',
                  borderRadius: 8, fontSize: 12, color: 'var(--text2)',
                  marginBottom: 6,
                }}>
                  🔔 {n.message}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
