import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

const statusColor = (s) => {
  if (s === 'Approved') return 'badge-green';
  if (s === 'Rejected') return 'badge-red';
  if (s === 'Department Review') return 'badge-purple';
  return 'badge-yellow';
};

const STEP_MAP = { 'Pending': 1, 'Department Review': 2, 'Approved': 3, 'Rejected': 1 };
const STEPS = ['Submitted', 'Department', 'Admin', 'Issued'];

export default function MyRequests() {
  const { currentUser, getRequestsByStudent } = useApp();
  const requests = getRequestsByStudent(currentUser.id);
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState('All');

  const filters = ['All', 'Pending', 'Department Review', 'Approved', 'Rejected'];
  const filtered = filter === 'All' ? requests : requests.filter(r => r.status === filter);

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">My Requests</h1>
        <p className="page-subtitle">Track all your certificate and ID card requests</p>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {filters.map(f => (
          <button key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: '6px 14px', borderRadius: 20, border: 'none',
              cursor: 'pointer', fontSize: 12, fontWeight: 600, fontFamily: 'var(--font)',
              background: filter === f ? 'var(--accent)' : 'var(--bg3)',
              color: filter === f ? '#fff' : 'var(--text2)',
              transition: 'all 0.18s',
            }}>
            {f} {f === 'All' ? `(${requests.length})` : `(${requests.filter(r => r.status === f).length})`}
          </button>
        ))}
      </div>

      {/* Modal for request detail */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <h3 style={{ fontSize: 17, fontWeight: 800 }}>{selected.type}</h3>
                <p style={{ color: 'var(--text3)', fontSize: 12 }}>Request ID: {selected.id}</p>
              </div>
              <button onClick={() => setSelected(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', fontSize: 20 }}>✕</button>
            </div>

            {/* Progress */}
            <div className="progress-steps" style={{ marginBottom: 24 }}>
              {STEPS.map((label, i) => {
                const step = STEP_MAP[selected.status] || 0;
                const isDone = selected.status !== 'Rejected' && i < step;
                const isActive = i === step - 1 || (selected.status === 'Approved' && i === 2);
                return (
                  <React.Fragment key={label}>
                    <div className={`step ${isDone || (selected.status === 'Approved' && i <= 2) ? 'done' : isActive ? 'active' : ''}`}>
                      <div className="step-circle">{(isDone || (selected.status === 'Approved' && i <= 2)) ? '✓' : i + 1}</div>
                      <div className="step-label">{label}</div>
                    </div>
                    {i < STEPS.length - 1 && (
                      <div className={`step-line ${(isDone || (selected.status === 'Approved' && i <= 1)) ? 'done' : ''}`} />
                    )}
                  </React.Fragment>
                );
              })}
            </div>

            {[
              ['Type', selected.type],
              ['Status', selected.status],
              ['Department', selected.dept],
              ['Roll Number', selected.rollNo],
              ['Reason', selected.reason],
              ['Submitted', selected.submittedAt],
              ['Last Updated', selected.updatedAt],
              selected.remarks && ['Remarks', selected.remarks],
            ].filter(Boolean).map(([k, v]) => (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
                padding: '10px 0', borderBottom: '1px solid var(--border)',
                fontSize: 13,
              }}>
                <span style={{ color: 'var(--text3)', minWidth: 120 }}>{k}</span>
                <span style={{ fontWeight: 600, textAlign: 'right', maxWidth: 280 }}>{v}</span>
              </div>
            ))}

            {selected.status === 'Rejected' && (
              <div style={{
                marginTop: 16, padding: '12px 14px',
                background: 'rgba(239,68,68,0.1)', borderRadius: 9,
                border: '1px solid rgba(239,68,68,0.2)',
                fontSize: 12, color: 'var(--red)',
              }}>
                ❌ This request was rejected. {selected.remarks ? `Reason: ${selected.remarks}` : 'Contact your department for more info.'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <span style={{ fontSize: 40 }}>📭</span>
            <p>No requests found for this filter.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Request ID</th>
                  <th>Type</th>
                  <th>Department</th>
                  <th>Submitted</th>
                  <th>Updated</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(req => (
                  <tr key={req.id}>
                    <td><span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{req.id}</span></td>
                    <td className="bold">{req.type}</td>
                    <td>{req.dept}</td>
                    <td>{req.submittedAt}</td>
                    <td>{req.updatedAt}</td>
                    <td><span className={`badge ${statusColor(req.status)}`}>{req.status}</span></td>
                    <td>
                      <button className="btn btn-secondary btn-sm" onClick={() => setSelected(req)}>
                        Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
