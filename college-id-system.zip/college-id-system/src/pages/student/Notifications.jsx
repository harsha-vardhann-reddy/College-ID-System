import React from 'react';
import { useApp } from '../../context/AppContext';

export default function Notifications() {
  const { currentUser, notifications, markNotificationRead } = useApp();
  const myNotifs = notifications.filter(n => n.userId === currentUser.id);

  return (
    <div className="page-body" style={{ maxWidth: 680, margin: '0 auto' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Notifications</h1>
        <p className="page-subtitle">{myNotifs.filter(n => !n.read).length} unread notifications</p>
      </div>

      {myNotifs.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <span style={{ fontSize: 48 }}>🔔</span>
            <p>No notifications yet. You'll be notified when your requests are updated.</p>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {myNotifs.map(n => (
            <div key={n.id} style={{
              padding: '16px 20px',
              background: n.read ? 'var(--card)' : 'rgba(59,130,246,0.06)',
              border: `1px solid ${n.read ? 'var(--border)' : 'rgba(59,130,246,0.25)'}`,
              borderRadius: 12,
              display: 'flex', gap: 14, alignItems: 'flex-start',
              cursor: 'pointer',
              transition: 'all 0.18s',
            }}
              onClick={() => markNotificationRead(n.id)}>
              <div style={{
                width: 38, height: 38, borderRadius: 10, flexShrink: 0,
                background: n.read ? 'var(--bg3)' : 'rgba(59,130,246,0.15)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18,
              }}>
                {n.message.includes('approved') ? '✅' : n.message.includes('rejected') ? '❌' : '🔔'}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 13.5, color: n.read ? 'var(--text2)' : 'var(--text)', lineHeight: 1.5 }}>
                  {n.message}
                </p>
                <span style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4, display: 'block' }}>
                  {n.time}
                </span>
              </div>
              {!n.read && (
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', marginTop: 6, flexShrink: 0 }} />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
