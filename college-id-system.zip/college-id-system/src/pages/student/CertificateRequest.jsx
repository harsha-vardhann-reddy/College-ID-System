import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const CERT_TYPES = [
  'Bonafide Certificate',
  'NOC',
  'Experience Letter',
  'Replacement ID Card',
];

const STEP_LABELS = ['Fill Details', 'Department', 'Admin Approval', 'Certificate Ready'];

export default function CertificateRequest() {
  const { submitRequest, currentUser, getStudentById } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const student = getStudentById(currentUser.id);

  const [form, setForm] = useState({
    type: location.state?.type || '',
    reason: '',
    urgency: 'Normal',
    dept: student?.dept || 'Computer Science',
    rollNo: student?.rollNo || currentUser.id,
  });
  const [submitted, setSubmitted] = useState(false);
  const [newReq, setNewReq] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const req = submitRequest(form);
    setNewReq(req);
    setSubmitted(true);
  };

  if (submitted && newReq) {
    return (
      <div className="page-body" style={{ maxWidth: 560, margin: '0 auto' }}>
        <div className="card" style={{ textAlign: 'center', padding: 40 }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>🎉</div>
          <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 8 }}>Request Submitted!</h2>
          <p style={{ color: 'var(--text3)', marginBottom: 24, fontSize: 13 }}>
            Your request for <strong style={{ color: 'var(--accent2)' }}>{newReq.type}</strong> has been submitted successfully.
          </p>

          {/* Status progress */}
          <div className="progress-steps" style={{ marginBottom: 28 }}>
            {STEP_LABELS.map((label, i) => (
              <React.Fragment key={label}>
                <div className={`step ${i === 0 ? 'done' : i === 1 ? 'active' : ''}`}>
                  <div className="step-circle">{i === 0 ? '✓' : i + 1}</div>
                  <div className="step-label">{label}</div>
                </div>
                {i < STEP_LABELS.length - 1 && (
                  <div className={`step-line ${i === 0 ? 'done' : ''}`} />
                )}
              </React.Fragment>
            ))}
          </div>

          <div style={{
            background: 'var(--bg3)', borderRadius: 10, padding: '14px 18px',
            border: '1px solid var(--border)', textAlign: 'left', marginBottom: 24,
          }}>
            <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Request Details
            </div>
            {[
              ['Request ID', newReq.id],
              ['Type', newReq.type],
              ['Department', newReq.dept],
              ['Submitted On', newReq.submittedAt],
              ['Status', 'Pending'],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13 }}>
                <span style={{ color: 'var(--text3)' }}>{k}</span>
                <span style={{ fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button className="btn btn-secondary" onClick={() => navigate('/student/my-requests')}>
              View My Requests
            </button>
            <button className="btn btn-primary" onClick={() => { setSubmitted(false); setForm({ type: '', reason: '', urgency: 'Normal', dept: student?.dept || '', rollNo: student?.rollNo || '' }); }}>
              New Request
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-body" style={{ maxWidth: 620, margin: '0 auto' }}>
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Request Certificate</h1>
        <p className="page-subtitle">Fill in the form below to submit a certificate request</p>
      </div>

      <div className="card">
        {/* Student info preview */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 14,
          padding: '14px 16px', background: 'var(--bg3)',
          borderRadius: 10, border: '1px solid var(--border)',
          marginBottom: 24,
        }}>
          <div className="avatar" style={{ width: 42, height: 42, fontSize: 16 }}>
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 14 }}>{currentUser.name}</div>
            <div style={{ fontSize: 12, color: 'var(--text3)' }}>
              {student?.course} · {student?.dept} · Roll: {student?.rollNo}
            </div>
          </div>
          <span className="badge badge-blue" style={{ marginLeft: 'auto' }}>Student</span>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Certificate Type *</label>
            <select className="form-select" value={form.type}
              onChange={e => setForm(p => ({ ...p, type: e.target.value }))} required>
              <option value="">-- Select certificate type --</option>
              {CERT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Reason / Purpose *</label>
            <textarea className="form-textarea" rows={3}
              placeholder="Briefly explain why you need this certificate..."
              value={form.reason}
              onChange={e => setForm(p => ({ ...p, reason: e.target.value }))}
              required />
          </div>

          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Urgency</label>
              <select className="form-select" value={form.urgency}
                onChange={e => setForm(p => ({ ...p, urgency: e.target.value }))}>
                <option>Normal</option>
                <option>Urgent</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Department</label>
              <input className="form-input" value={form.dept} readOnly style={{ opacity: 0.7 }} />
            </div>
          </div>

          <div style={{
            background: 'rgba(245,158,11,0.08)',
            border: '1px solid rgba(245,158,11,0.2)',
            borderRadius: 9, padding: '12px 14px',
            fontSize: 12, color: 'var(--yellow)',
            marginBottom: 20,
          }}>
            ⚠️ Once submitted, your request will go through Department Review → Admin Approval workflow.
            You'll be notified at each stage.
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button type="button" className="btn btn-secondary" onClick={() => navigate(-1)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: 'center' }}>
              Submit Request →
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
