import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function AdminDashboard() {
  const { requests, students } = useApp();
  const navigate = useNavigate();

  const pending = requests.filter(r => r.status === 'Pending').length;
  const approved = requests.filter(r => r.status === 'Approved').length;
  const rejected = requests.filter(r => r.status === 'Rejected').length;
  const deptReview = requests.filter(r => r.status === 'Department Review').length;

  const stats = [
    { label: 'Total Requests', value: requests.length, icon: '📄', color: '#3b82f6', bg: 'rgba(59,130,246,0.1)' },
    { label: 'Pending Approval', value: pending, icon: '⏳', color: '#f59e0b', bg: 'rgba(245,158,11,0.1)' },
    { label: 'Approved', value: approved, icon: '✅', color: '#10b981', bg: 'rgba(16,185,129,0.1)' },
    { label: 'Total Students', value: students.length, icon: '👨‍🎓', color: '#8b5cf6', bg: 'rgba(139,92,246,0.1)' },
  ];

  const pieData = [
    { name: 'Approved', value: approved, color: '#10b981' },
    { name: 'Pending', value: pending, color: '#f59e0b' },
    { name: 'Dept Review', value: deptReview, color: '#8b5cf6' },
    { name: 'Rejected', value: rejected, color: '#ef4444' },
  ].filter(d => d.value > 0);

  // Cert type breakdown
  const certTypes = ['Bonafide Certificate', 'NOC', 'Experience Letter', 'Replacement ID Card'];
  const barData = certTypes.map(type => ({
    name: type.replace('Certificate', 'Cert.').replace('Experience Letter', 'Exp. Letter'),
    count: requests.filter(r => r.type === type).length,
  }));

  const recentPending = requests.filter(r => r.status === 'Pending' || r.status === 'Department Review').slice(0, 5);

  return (
    <div className="page-body">
      <div style={{ marginBottom: 28 }}>
        <h1 className="page-title">Admin Dashboard</h1>
        <p className="page-subtitle">Overview of certificate requests and student management</p>
      </div>

      <div className="grid-4 mb-6">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon" style={{ background: s.bg }}>
              <span style={{ fontSize: 20 }}>{s.icon}</span>
            </div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2 gap-6 mb-6">
        {/* Bar chart */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Requests by Type</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={barData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: 'var(--text3)', fontSize: 10 }} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} />
              <Tooltip
                contentStyle={{ background: 'var(--card)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }}
                cursor={{ fill: 'rgba(59,130,246,0.05)' }}
              />
              <Bar dataKey="count" fill="var(--accent)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>Status Distribution</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <ResponsiveContainer width="50%" height={180}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75}
                  dataKey="value" paddingAngle={3}>
                  {pieData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--card)', border: '1px solid var(--border2)', borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1 }}>
              {pieData.map(d => (
                <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: d.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: 'var(--text2)' }}>{d.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, marginLeft: 'auto', fontFamily: 'var(--mono)' }}>{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Pending requests quick view */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 style={{ fontSize: 15, fontWeight: 700 }}>Pending & Under Review ({recentPending.length})</h3>
          <button className="btn btn-primary btn-sm" onClick={() => navigate('/admin/requests')}>
            Manage All →
          </button>
        </div>

        {recentPending.length === 0 ? (
          <div className="empty-state" style={{ padding: '24px' }}>
            <span style={{ fontSize: 32 }}>🎉</span>
            <p>All requests have been processed!</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Certificate Type</th>
                  <th>Roll No</th>
                  <th>Submitted</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {recentPending.map(req => (
                  <tr key={req.id}>
                    <td className="bold">{req.studentName}</td>
                    <td>{req.type}</td>
                    <td><span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{req.rollNo}</span></td>
                    <td>{req.submittedAt}</td>
                    <td>
                      <span className={`badge ${req.status === 'Pending' ? 'badge-yellow' : 'badge-purple'}`}>
                        {req.status}
                      </span>
                    </td>
                    <td>
                      <button className="btn btn-secondary btn-sm"
                        onClick={() => navigate('/admin/requests')}>
                        Review
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
