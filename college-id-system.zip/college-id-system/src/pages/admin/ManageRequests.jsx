import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

const statusColor = (s) => {
  if (s === 'Approved') return 'badge-green';
  if (s === 'Rejected') return 'badge-red';
  if (s === 'Department Review') return 'badge-purple';
  return 'badge-yellow';
};

export default function ManageRequests() {
  const { requests, updateRequestStatus } = useApp();
  const [filter, setFilter] = useState('All');
  const [selected, setSelected] = useState(null);
  const [remarks, setRemarks] = useState('');
  const [search, setSearch] = useState('');

  const filters = ['All', 'Pending', 'Department Review', 'Approved', 'Rejected'];

  let filtered = filter === 'All' ? requests : requests.filter(r => r.status === filter);
  if (search) {
    filtered = filtered.filter(r =>
      r.studentName.toLowerCase().includes(search.toLowerCase()) ||
      r.type.toLowerCase().includes(search.toLowerCase()) ||
      r.rollNo.toLowerCase().includes(search.toLowerCase())
    );
  }

  const handleAction = (status) => {
    updateRequestStatus(selected.id, status, remarks);
    setSelected(null);
    setRemarks('');
  };

  const handleAdvance = () => {
    if (selected.status === 'Pending') {
      updateRequestStatus(selected.id, 'Department Review', '');
    } else if (selected.status === 'Department Review') {
      updateRequestStatus(selected.id, 'Approved', remarks);
    }
    setSelected(null);
    setRemarks('');
  };

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Manage Requests</h1>
        <p className="page-subtitle">Review, approve, or reject student certificate requests</p>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center' }}>
        <div className="search-bar" style={{ flex: 1, minWidth: 200 }}>
          <span style={{ color: 'var(--text3)' }}>🔍</span>
          <input placeholder="Search by name, type, roll no..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {filters.map(f => (
            <button key={f}
              onClick={() => setFilter(f)}
              style={{
                padding: '6px 14px', borderRadius: 20, border: 'none',
                cursor: 'pointer', fontSize: 12, fontWeight: 600, fontFamily: 'var(--font)',
                background: filter === f ? 'var(--accent)' : 'var(--bg3)',
                color: filter === f ? '#fff' : 'var(--text2)',
              }}>
              {f} ({f === 'All' ? requests.length : requests.filter(r => r.status === f).length})
            </button>
          ))}
        </div>
      </div>

      {/* Review Modal */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div>
                <h3 style={{ fontSize: 17, fontWeight: 800 }}>Review Request</h3>
                <p style={{ color: 'var(--text3)', fontSize: 12 }}>{selected.id}</p>
              </div>
              <button onClick={() => setSelected(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', fontSize: 20 }}>✕</button>
            </div>

            {/* Current status badge */}
            <div style={{ marginBottom: 16 }}>
              <span className={`badge ${statusColor(selected.status)}`} style={{ fontSize: 12 }}>
                Current: {selected.status}
              </span>
            </div>

            {[
              ['Student', selected.studentName],
              ['Roll No', selected.rollNo],
              ['Department', selected.dept],
              ['Certificate Type', selected.type],
              ['Reason', selected.reason],
              ['Submitted', selected.submittedAt],
            ].map(([k, v]) => (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '9px 0', borderBottom: '1px solid var(--border)', fontSize: 13,
              }}>
                <span style={{ color: 'var(--text3)', minWidth: 130 }}>{k}</span>
                <span style={{ fontWeight: 600, textAlign: 'right' }}>{v}</span>
              </div>
            ))}

            {(selected.status === 'Pending' || selected.status === 'Department Review') && (
              <>
                <div className="form-group" style={{ marginTop: 18 }}>
                  <label className="form-label">Remarks (optional)</label>
                  <textarea className="form-textarea" rows={2}
                    placeholder="Add remarks for approval or rejection..."
                    value={remarks}
                    onChange={e => setRemarks(e.target.value)} />
                </div>

                <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                  {selected.status === 'Pending' && (
                    <button className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }}
                      onClick={() => { updateRequestStatus(selected.id, 'Department Review', ''); setSelected(null); }}>
                      → Dept Review
                    </button>
                  )}
                  {selected.status === 'Department Review' && (
                    <button className="btn btn-green" style={{ flex: 1, justifyContent: 'center' }}
                      onClick={() => handleAction('Approved')}>
                      ✅ Approve
                    </button>
                  )}
                  <button className="btn btn-red" style={{ flex: 1, justifyContent: 'center' }}
                    onClick={() => handleAction('Rejected')}>
                    ❌ Reject
                  </button>
                </div>
              </>
            )}

            {selected.status === 'Approved' && (
              <div style={{ marginTop: 16, padding: '12px 14px', background: 'rgba(16,185,129,0.1)', borderRadius: 9, border: '1px solid rgba(16,185,129,0.2)', fontSize: 13, color: 'var(--green)' }}>
                ✅ This request has been approved. Certificate can be generated.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <span style={{ fontSize: 40 }}>📭</span>
            <p>No requests found.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Student</th>
                  <th>Roll No</th>
                  <th>Type</th>
                  <th>Dept</th>
                  <th>Submitted</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(req => (
                  <tr key={req.id}>
                    <td><span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{req.id}</span></td>
                    <td className="bold">{req.studentName}</td>
                    <td><span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{req.rollNo}</span></td>
                    <td style={{ maxWidth: 160 }}>{req.type}</td>
                    <td>{req.dept}</td>
                    <td>{req.submittedAt}</td>
                    <td><span className={`badge ${statusColor(req.status)}`}>{req.status}</span></td>
                    <td>
                      <button className="btn btn-secondary btn-sm"
                        onClick={() => { setSelected(req); setRemarks(req.remarks || ''); }}>
                        Review
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
