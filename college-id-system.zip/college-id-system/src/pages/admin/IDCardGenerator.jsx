import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

function IDCard({ student }) {
  if (!student) return null;
  return (
    <div style={{ width: 340, borderRadius: 16, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.5)', display: 'inline-block' }}>
      <div style={{ background: 'linear-gradient(135deg, #1e3a8a, #1d4ed8, #3b82f6)', padding: '18px 20px 14px', textAlign: 'center' }}>
        <div style={{ fontSize: 13, fontWeight: 800, color: '#fff', letterSpacing: 0.5 }}>🎓 COLLEGE OF ENGINEERING & TECHNOLOGY</div>
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>Hyderabad, Telangana · NAAC Accredited</div>
        <div style={{ marginTop: 10, background: 'rgba(255,255,255,0.15)', borderRadius: 4, padding: '3px 10px', display: 'inline-block', fontSize: 10, fontWeight: 700, color: '#fff', letterSpacing: 1, textTransform: 'uppercase' }}>
          Student Identity Card
        </div>
      </div>
      <div style={{ background: '#fff', padding: '20px', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
        <div style={{ width: 75, height: 90, flexShrink: 0, background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, color: '#fff', fontWeight: 800, border: '2px solid #1e3a8a' }}>
          {student.name?.charAt(0)}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: '#1e293b', lineHeight: 1.2 }}>{student.name}</div>
          <div style={{ fontSize: 10, color: '#64748b', marginBottom: 8, marginTop: 2 }}>{student.course}</div>
          {[['Roll No', student.rollNo], ['Dept', student.dept], ['Year', student.year], ['Phone', student.phone]].map(([k, v]) => v && (
            <div key={k} style={{ display: 'flex', gap: 6, marginBottom: 3 }}>
              <span style={{ fontSize: 9, color: '#94a3b8', minWidth: 40, fontWeight: 600, textTransform: 'uppercase' }}>{k}:</span>
              <span style={{ fontSize: 10, color: '#334155', fontWeight: 600 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ background: '#f8fafc', padding: '8px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontFamily: 'monospace', fontSize: 9, color: '#475569' }}>
          {'||| |||| | ||| ||||| | ||||'}
          <div style={{ fontSize: 8, marginTop: 1 }}>{student.rollNo}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 8, color: '#94a3b8' }}>Valid Until</div>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#1e293b' }}>May 2026</div>
        </div>
      </div>
      <div style={{ background: '#1e3a8a', padding: '10px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.6)' }}>If found, return to<br />administration</div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 8, color: 'rgba(255,255,255,0.5)' }}>Authorized by</div>
          <div style={{ fontSize: 9, color: '#fff', fontWeight: 600 }}>Principal</div>
        </div>
      </div>
    </div>
  );
}

export default function IDCardGenerator() {
  const { students } = useApp();
  const [selectedId, setSelectedId] = useState('');
  const student = students.find(s => s.id === selectedId);

  const handlePrint = () => window.print();

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">ID Card Generator</h1>
        <p className="page-subtitle">Generate and print student ID cards</p>
      </div>

      <div className="grid-2 gap-6">
        {/* Controls */}
        <div>
          <div className="card mb-4">
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Select Student</h3>
            <div className="form-group">
              <label className="form-label">Choose a student to generate ID card</label>
              <select className="form-select" value={selectedId} onChange={e => setSelectedId(e.target.value)}>
                <option value="">-- Select Student --</option>
                {students.map(s => (
                  <option key={s.id} value={s.id}>{s.name} — {s.rollNo}</option>
                ))}
              </select>
            </div>

            {student && (
              <div style={{ marginTop: 8 }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '12px', background: 'var(--bg3)', borderRadius: 10,
                  border: '1px solid var(--border)', marginBottom: 16,
                }}>
                  <div className="avatar" style={{ width: 38, height: 38, fontSize: 16 }}>{student.name.charAt(0)}</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{student.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)' }}>{student.course} · {student.rollNo}</div>
                  </div>
                </div>
                <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={handlePrint}>
                  🖨️ Print ID Card
                </button>
              </div>
            )}
          </div>

          {/* Bulk generate info */}
          <div className="card">
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 12 }}>All Students ({students.length})</h3>
            <div style={{ maxHeight: 320, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {students.map(s => (
                <button key={s.id}
                  onClick={() => setSelectedId(s.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '10px 12px', background: selectedId === s.id ? 'rgba(59,130,246,0.1)' : 'var(--bg3)',
                    border: `1px solid ${selectedId === s.id ? 'var(--accent)' : 'var(--border)'}`,
                    borderRadius: 9, cursor: 'pointer', textAlign: 'left',
                    transition: 'all 0.18s',
                  }}>
                  <div className="avatar" style={{ width: 30, height: 30, fontSize: 12, flexShrink: 0 }}>{s.name.charAt(0)}</div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 12, color: 'var(--text)' }}>{s.name}</div>
                    <div style={{ fontSize: 10, color: 'var(--text3)', fontFamily: 'var(--mono)' }}>{s.rollNo} · {s.dept}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Card Preview */}
        <div>
          <div className="card">
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 20 }}>
              {student ? 'ID Card Preview' : 'Select a student to preview'}
            </h3>
            {student ? (
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <IDCard student={student} />
              </div>
            ) : (
              <div className="empty-state">
                <span style={{ fontSize: 48 }}>🪪</span>
                <p>Select a student from the list to generate their ID card</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
