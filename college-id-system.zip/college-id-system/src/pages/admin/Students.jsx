import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export default function Students() {
  const { students, addStudent, updateStudent, deleteStudent } = useApp();
  const [modal, setModal] = useState(null); // null | 'add' | 'edit'
  const [editStudent, setEditStudent] = useState(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', email: '', course: 'B.Tech CSE', year: '1st Year', dept: 'Computer Science', phone: '', rollNo: '' });

  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.rollNo?.toLowerCase().includes(search.toLowerCase()) ||
    s.dept?.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setForm({ name: '', email: '', course: 'B.Tech CSE', year: '1st Year', dept: 'Computer Science', phone: '', rollNo: '' });
    setModal('add');
  };

  const openEdit = (s) => {
    setEditStudent(s);
    setForm({ name: s.name, email: s.email, course: s.course, year: s.year, dept: s.dept, phone: s.phone, rollNo: s.rollNo });
    setModal('edit');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (modal === 'add') addStudent(form);
    else updateStudent(editStudent.id, form);
    setModal(null);
  };

  const handleDelete = (id) => {
    if (window.confirm('Delete this student record?')) deleteStudent(id);
  };

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Student Management</h1>
        <p className="page-subtitle">Add, edit, or remove student records</p>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 20, alignItems: 'center' }}>
        <div className="search-bar" style={{ flex: 1 }}>
          <span style={{ color: 'var(--text3)' }}>🔍</span>
          <input placeholder="Search by name, roll no, department..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Student</button>
      </div>

      {/* Modal */}
      {modal && (
        <div className="modal-overlay" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <h3 style={{ fontSize: 17, fontWeight: 800 }}>{modal === 'add' ? 'Add New Student' : 'Edit Student'}</h3>
              <button onClick={() => setModal(null)}
                style={{ background: 'none', border: 'none', color: 'var(--text3)', cursor: 'pointer', fontSize: 20 }}>✕</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input className="form-input" required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Full name" />
                </div>
                <div className="form-group">
                  <label className="form-label">Roll Number *</label>
                  <input className="form-input" required value={form.rollNo} onChange={e => setForm(p => ({ ...p, rollNo: e.target.value }))} placeholder="e.g. 2520030523" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input className="form-input" required type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} placeholder="student@college.edu" />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Course</label>
                  <select className="form-select" value={form.course} onChange={e => setForm(p => ({ ...p, course: e.target.value }))}>
                    {['B.Tech CSE', 'B.Tech ECE', 'B.Tech MECH', 'B.Tech CIVIL', 'MCA', 'MBA'].map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Year</label>
                  <select className="form-select" value={form.year} onChange={e => setForm(p => ({ ...p, year: e.target.value }))}>
                    {['1st Year', '2nd Year', '3rd Year', '4th Year'].map(y => <option key={y}>{y}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Department</label>
                  <select className="form-select" value={form.dept} onChange={e => setForm(p => ({ ...p, dept: e.target.value }))}>
                    {['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Information Technology'].map(d => <option key={d}>{d}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Phone</label>
                  <input className="form-input" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} placeholder="10-digit mobile" />
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary" style={{ flex: 1, justifyContent: 'center' }}>
                  {modal === 'add' ? 'Add Student' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', fontSize: 12, color: 'var(--text3)' }}>
          {filtered.length} students found
        </div>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <span style={{ fontSize: 40 }}>👨‍🎓</span>
            <p>No students found. Add one using the button above.</p>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Roll No</th>
                  <th>Email</th>
                  <th>Course</th>
                  <th>Year</th>
                  <th>Department</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => (
                  <tr key={s.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div className="avatar" style={{ width: 30, height: 30, fontSize: 12 }}>{s.name.charAt(0)}</div>
                        <span style={{ fontWeight: 600, color: 'var(--text)' }}>{s.name}</span>
                      </div>
                    </td>
                    <td><span style={{ fontFamily: 'var(--mono)', fontSize: 12 }}>{s.rollNo}</span></td>
                    <td>{s.email}</td>
                    <td>{s.course}</td>
                    <td>{s.year}</td>
                    <td>{s.dept}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-secondary btn-sm" onClick={() => openEdit(s)}>✏️</button>
                        <button className="btn btn-red btn-sm" onClick={() => handleDelete(s.id)}>🗑️</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
