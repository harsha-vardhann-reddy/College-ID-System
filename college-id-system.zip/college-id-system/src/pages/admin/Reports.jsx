import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export default function Reports() {
  const { requests, students } = useApp();
  const [exportType, setExportType] = useState('all');

  const approved = requests.filter(r => r.status === 'Approved');
  const pending = requests.filter(r => r.status === 'Pending');
  const rejected = requests.filter(r => r.status === 'Rejected');

  // Cert type stats
  const certTypes = ['Bonafide Certificate', 'NOC', 'Experience Letter', 'Replacement ID Card'];
  const certStats = certTypes.map(type => ({
    type,
    total: requests.filter(r => r.type === type).length,
    approved: requests.filter(r => r.type === type && r.status === 'Approved').length,
    pending: requests.filter(r => r.type === type && r.status === 'Pending').length,
  }));

  // Export to CSV
  const exportCSV = () => {
    let data = exportType === 'all' ? requests
      : exportType === 'approved' ? approved
      : exportType === 'pending' ? pending
      : rejected;

    const headers = ['Request ID', 'Student Name', 'Roll No', 'Department', 'Certificate Type', 'Reason', 'Status', 'Submitted Date', 'Updated Date', 'Remarks'];
    const rows = data.map(r => [
      r.id, r.studentName, r.rollNo, r.dept, r.type, r.reason, r.status, r.submittedAt, r.updatedAt, r.remarks || ''
    ]);

    const csvContent = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `certificates_${exportType}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  // Export students
  const exportStudents = () => {
    const headers = ['Student ID', 'Name', 'Roll No', 'Email', 'Course', 'Year', 'Department', 'Phone'];
    const rows = students.map(s => [s.id, s.name, s.rollNo, s.email, s.course, s.year, s.dept, s.phone || '']);
    const csv = [headers, ...rows].map(row => row.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `students_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="page-body">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Reports & Export</h1>
        <p className="page-subtitle">View summary statistics and export data in bulk</p>
      </div>

      {/* Summary cards */}
      <div className="grid-4 mb-6">
        {[
          { label: 'Total Requests', value: requests.length, color: '#3b82f6' },
          { label: 'Approved', value: approved.length, color: '#10b981' },
          { label: 'Pending', value: pending.length, color: '#f59e0b' },
          { label: 'Rejected', value: rejected.length, color: '#ef4444' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ borderTop: `3px solid ${s.color}` }}>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
            <div style={{ fontSize: 11, color: 'var(--text3)' }}>
              {s.value > 0 ? `${Math.round(s.value / requests.length * 100)}% of total` : '—'}
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2 gap-6">
        {/* Certificate type breakdown */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>By Certificate Type</h3>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Total</th>
                  <th>Approved</th>
                  <th>Pending</th>
                </tr>
              </thead>
              <tbody>
                {certStats.map(c => (
                  <tr key={c.type}>
                    <td className="bold" style={{ fontSize: 12 }}>{c.type}</td>
                    <td><span style={{ fontFamily: 'var(--mono)', fontWeight: 700 }}>{c.total}</span></td>
                    <td><span className="badge badge-green">{c.approved}</span></td>
                    <td><span className="badge badge-yellow">{c.pending}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Export */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Export Data</h3>

          <div className="form-group">
            <label className="form-label">Export Requests</label>
            <select className="form-select" value={exportType} onChange={e => setExportType(e.target.value)}>
              <option value="all">All Requests ({requests.length})</option>
              <option value="approved">Approved Only ({approved.length})</option>
              <option value="pending">Pending Only ({pending.length})</option>
              <option value="rejected">Rejected Only ({rejected.length})</option>
            </select>
          </div>
          <button className="btn btn-primary mb-4" style={{ width: '100%', justifyContent: 'center' }} onClick={exportCSV}>
            📥 Download Requests CSV
          </button>

          <div style={{ borderTop: '1px solid var(--border)', paddingTop: 16, marginTop: 4 }}>
            <div className="form-label" style={{ marginBottom: 10 }}>Export Students</div>
            <button className="btn btn-secondary" style={{ width: '100%', justifyContent: 'center' }} onClick={exportStudents}>
              📥 Download Students CSV ({students.length} records)
            </button>
          </div>

          <div style={{
            marginTop: 16, padding: '12px 14px',
            background: 'rgba(59,130,246,0.08)',
            border: '1px solid rgba(59,130,246,0.2)',
            borderRadius: 9, fontSize: 12, color: 'var(--accent2)',
          }}>
            📊 Files are exported as CSV format — compatible with Excel, Google Sheets, etc.
          </div>
        </div>
      </div>

      {/* Full request history */}
      <div className="card mt-6" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', fontWeight: 700, fontSize: 15 }}>
          Full Request History
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Student</th>
                <th>Roll No</th>
                <th>Type</th>
                <th>Submitted</th>
                <th>Updated</th>
                <th>Status</th>
                <th>Remarks</th>
              </tr>
            </thead>
            <tbody>
              {requests.map(req => (
                <tr key={req.id}>
                  <td><span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{req.id}</span></td>
                  <td className="bold">{req.studentName}</td>
                  <td><span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{req.rollNo}</span></td>
                  <td style={{ fontSize: 12 }}>{req.type}</td>
                  <td>{req.submittedAt}</td>
                  <td>{req.updatedAt}</td>
                  <td>
                    <span className={`badge ${req.status === 'Approved' ? 'badge-green' : req.status === 'Rejected' ? 'badge-red' : req.status === 'Department Review' ? 'badge-purple' : 'badge-yellow'}`}>
                      {req.status}
                    </span>
                  </td>
                  <td style={{ fontSize: 11, color: 'var(--text3)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {req.remarks || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
