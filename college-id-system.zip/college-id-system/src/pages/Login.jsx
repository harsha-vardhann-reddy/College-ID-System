import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export default function Login() {
  const { login } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      const result = login(form.username, form.password);
      setLoading(false);
      if (result.success) {
        navigate(result.user.role === 'admin' ? '/admin/dashboard' : '/student/dashboard');
      } else {
        setError('Invalid username or password');
      }
    }, 600);
  };

  return (
    <div className="login-page">
      <div className="login-bg" />
      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 420, padding: '0 16px' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64,
            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
            borderRadius: 16,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 16px',
            fontSize: 28,
          }}>🎓</div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: 'var(--text)' }}>College ID System</h1>
          <p style={{ color: 'var(--text3)', fontSize: 13, marginTop: 6 }}>Certificate & ID Card Issuance Portal</p>
        </div>

        <div className="login-card">
          <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>Sign in</h2>
          <p style={{ color: 'var(--text3)', fontSize: 12, marginBottom: 24 }}>Use your college credentials</p>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Username</label>
              <input
                className="form-input"
                type="text"
                placeholder="e.g. sandeep or admin"
                value={form.username}
                onChange={e => setForm(p => ({ ...p, username: e.target.value }))}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="••••••••"
                value={form.password}
                onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                required
              />
            </div>

            {error && (
              <div style={{
                background: 'rgba(239,68,68,0.1)',
                border: '1px solid rgba(239,68,68,0.3)',
                borderRadius: 8, padding: '10px 14px',
                color: 'var(--red)', fontSize: 12, marginBottom: 16,
              }}>
                {error}
              </div>
            )}

            <button className="btn btn-primary" type="submit" disabled={loading}
              style={{ width: '100%', justifyContent: 'center', padding: '12px' }}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          {/* Demo credentials */}
          <div style={{
            marginTop: 24, padding: '14px',
            background: 'var(--bg3)',
            borderRadius: 10, border: '1px solid var(--border)',
          }}>
            <p style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 8, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Demo Credentials
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { label: 'Student', user: 'sandeep', pass: 'student123' },
                { label: 'Admin', user: 'admin', pass: 'admin123' },
              ].map(c => (
                <button key={c.user}
                  onClick={() => setForm({ username: c.user, password: c.pass })}
                  style={{
                    background: 'var(--bg)',
                    border: '1px solid var(--border2)',
                    borderRadius: 7, padding: '7px 12px',
                    cursor: 'pointer', color: 'var(--text2)',
                    fontSize: 12, textAlign: 'left', fontFamily: 'var(--font)',
                    display: 'flex', justifyContent: 'space-between',
                  }}>
                  <span style={{ fontWeight: 600 }}>{c.label}</span>
                  <span style={{ fontFamily: 'var(--mono)', color: 'var(--accent2)' }}>{c.user} / {c.pass}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
