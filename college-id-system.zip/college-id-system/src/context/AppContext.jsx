import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

const INITIAL_STUDENTS = [
  { id: 'STU001', name: 'Sandeep Bangaru', email: 'sandeep@college.edu', course: 'B.Tech CSE', year: '3rd Year', dept: 'Computer Science', phone: '9876543210', photo: null, rollNo: '2520030523' },
  { id: 'STU002', name: 'Harsha Vardhan', email: 'harsha@college.edu', course: 'B.Tech CSE', year: '3rd Year', dept: 'Computer Science', phone: '9876543211', photo: null, rollNo: '2520090180' },
  { id: 'STU003', name: 'Purna Chandar Rao', email: 'purna@college.edu', course: 'B.Tech CSE', year: '3rd Year', dept: 'Computer Science', phone: '9876543212', photo: null, rollNo: '2520090188' },
];

const INITIAL_REQUESTS = [
  { id: 'REQ001', studentId: 'STU001', studentName: 'Sandeep Bangaru', type: 'Bonafide Certificate', reason: 'For bank account opening', status: 'Approved', submittedAt: '2025-06-01', updatedAt: '2025-06-02', dept: 'Computer Science', rollNo: '2520030523', remarks: '' },
  { id: 'REQ002', studentId: 'STU002', studentName: 'Harsha Vardhan', type: 'NOC', reason: 'For internship application', status: 'Pending', submittedAt: '2025-06-03', updatedAt: '2025-06-03', dept: 'Computer Science', rollNo: '2520090180', remarks: '' },
  { id: 'REQ003', studentId: 'STU003', studentName: 'Purna Chandar Rao', type: 'Experience Letter', reason: 'For job application', status: 'Department Review', submittedAt: '2025-06-04', updatedAt: '2025-06-04', dept: 'Computer Science', rollNo: '2520090188', remarks: '' },
  { id: 'REQ004', studentId: 'STU001', studentName: 'Sandeep Bangaru', type: 'Replacement ID Card', reason: 'Lost original ID card', status: 'Rejected', submittedAt: '2025-05-28', updatedAt: '2025-05-30', dept: 'Computer Science', rollNo: '2520030523', remarks: 'Please submit FIR copy' },
];

const USERS = [
  { id: 'STU001', username: 'sandeep', password: 'student123', role: 'student', name: 'Sandeep Bangaru' },
  { id: 'STU002', username: 'harsha', password: 'student123', role: 'student', name: 'Harsha Vardhan' },
  { id: 'STU003', username: 'purna', password: 'student123', role: 'student', name: 'Purna Chandar Rao' },
  { id: 'ADM001', username: 'admin', password: 'admin123', role: 'admin', name: 'Dr. Admin' },
];

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem('currentUser');
    return saved ? JSON.parse(saved) : null;
  });

  const [students, setStudents] = useState(() => {
    const saved = localStorage.getItem('students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [requests, setRequests] = useState(() => {
    const saved = localStorage.getItem('requests');
    return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
  });

  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem('notifications');
    return saved ? JSON.parse(saved) : [
      { id: 'N001', userId: 'STU001', message: 'Your Bonafide Certificate request has been approved!', read: false, time: '2025-06-02' },
      { id: 'N002', userId: 'STU001', message: 'Your Replacement ID Card request was rejected. Please submit FIR copy.', read: false, time: '2025-05-30' },
    ];
  });

  useEffect(() => { localStorage.setItem('students', JSON.stringify(students)); }, [students]);
  useEffect(() => { localStorage.setItem('requests', JSON.stringify(requests)); }, [requests]);
  useEffect(() => { localStorage.setItem('notifications', JSON.stringify(notifications)); }, [notifications]);
  useEffect(() => {
    if (currentUser) localStorage.setItem('currentUser', JSON.stringify(currentUser));
    else localStorage.removeItem('currentUser');
  }, [currentUser]);

  const login = (username, password) => {
    const user = USERS.find(u => u.username === username && u.password === password);
    if (user) { setCurrentUser(user); return { success: true, user }; }
    return { success: false, message: 'Invalid credentials' };
  };

  const logout = () => setCurrentUser(null);

  const submitRequest = (requestData) => {
    const newReq = {
      id: 'REQ' + Date.now(),
      studentId: currentUser.id,
      studentName: currentUser.name,
      ...requestData,
      status: 'Pending',
      submittedAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      remarks: '',
    };
    setRequests(prev => [newReq, ...prev]);
    return newReq;
  };

  const updateRequestStatus = (reqId, status, remarks = '') => {
    setRequests(prev => prev.map(r =>
      r.id === reqId ? { ...r, status, remarks, updatedAt: new Date().toISOString().split('T')[0] } : r
    ));
    const req = requests.find(r => r.id === reqId);
    if (req) {
      const notif = {
        id: 'N' + Date.now(),
        userId: req.studentId,
        message: `Your ${req.type} request has been ${status}. ${remarks ? 'Remarks: ' + remarks : ''}`,
        read: false,
        time: new Date().toISOString().split('T')[0],
      };
      setNotifications(prev => [notif, ...prev]);
    }
  };

  const addStudent = (studentData) => {
    const newStudent = { id: 'STU' + Date.now(), ...studentData };
    setStudents(prev => [newStudent, ...prev]);
    return newStudent;
  };

  const updateStudent = (id, data) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...data } : s));
  };

  const deleteStudent = (id) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  const markNotificationRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const getStudentById = (id) => students.find(s => s.id === id);
  const getRequestsByStudent = (id) => requests.filter(r => r.studentId === id);
  const getUnreadCount = (userId) => notifications.filter(n => n.userId === userId && !n.read).length;

  return (
    <AppContext.Provider value={{
      currentUser, login, logout,
      students, addStudent, updateStudent, deleteStudent, getStudentById,
      requests, submitRequest, updateRequestStatus, getRequestsByStudent,
      notifications, markNotificationRead, getUnreadCount,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
