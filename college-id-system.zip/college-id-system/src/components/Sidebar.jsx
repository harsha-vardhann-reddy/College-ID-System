import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const StudentNav = [
  { icon: '🏠', label: 'Dashboard', path: '/student/dashboard' },
  { icon: '📄', label: 'Request Certificate', path: '/student/request' },
  { icon: '📋', label: 'My Requests', path: '/student/my-requests' },
  { icon: '🪪', label: 'My ID Card', path: '/student/id-card' },
  { icon: '🔔', label: 'Notifications', path: '/student/notifications' },
];

const AdminNav = [
  { icon: '🏠', label: 'Dashboard', path: '/admin/dashboard' },
  { icon: '📋', label: 'Manage Requests', path: '/admin/requests' },
  { icon: '👨‍🎓', label: 'Students', path: '/admin/students' },
  { icon: '🪪', label: 'ID Card Generator', path: '/admin/id-cards' },
  { icon: '📊', label: 'Reports & Export', path: '/admin/reports' },
];

export default function Sidebar() {
  const { currentUser, logout, getUnreadCount } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  if (!currentUser) return null;

  const navItems = currentUser.role === 'admin' ? AdminNav : StudentNav;
  const unread = getUnreadCount(currentUser.id);

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-badge">
          <div className="logo-icon">🎓</div>
          <div className="logo-text">
            <h2>College ID &<br/>Certificate System</h2>
            <span>v1.0 · {currentUser.role.toUpperCase()}</span>
          </div>
        </div>
      </div>

      <nav className="sidebar-nav">
        <div className="nav-section-label">Navigation</div>
        {navItems.map(item => (
          <button
            key={item.path}
            className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            onClick={() => navigate(item.path)}
          >
            <span>{item.icon}</span>
            <span style={{ flex: 1 }}>{item.label}</span>
            {item.label === 'Notifications' && unread > 0 && (
              <span style={{
                background: 'var(--red)', color: '#fff',
                borderRadius: 10, padding: '1px 6px',
                fontSize: 10, fontWeight: 700,
              }}>{unread}</span>
            )}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="user-card">
          <div className="avatar">{currentUser.name.charAt(0)}</div>
          <div className="user-info" style={{ flex: 1, overflow: 'hidden' }}>
            <h4 style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{currentUser.name}</h4>
            <p>{currentUser.role === 'admin' ? 'Administrator' : currentUser.id}</p>
          </div>
          <button onClick={() => { logout(); navigate('/login'); }}
            title="Logout"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', padding: '4px', borderRadius: 6 }}>
            🚪
          </button>
        </div>
      </div>
    </div>
  );
}
