import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/Sidebar';

// Pages
import Login from './pages/Login';
import StudentDashboard from './pages/student/StudentDashboard';
import CertificateRequest from './pages/student/CertificateRequest';
import MyRequests from './pages/student/MyRequests';
import StudentIDCard from './pages/student/StudentIDCard';
import Notifications from './pages/student/Notifications';
import AdminDashboard from './pages/admin/AdminDashboard';
import ManageRequests from './pages/admin/ManageRequests';
import Students from './pages/admin/Students';
import IDCardGenerator from './pages/admin/IDCardGenerator';
import Reports from './pages/admin/Reports';

import './index.css';

function ProtectedLayout({ children, role }) {
  const { currentUser } = useApp();
  if (!currentUser) return <Navigate to="/login" />;
  if (role && currentUser.role !== role) return <Navigate to={currentUser.role === 'admin' ? '/admin/dashboard' : '/student/dashboard'} />;
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-content">
        {children}
      </div>
    </div>
  );
}

function AppRoutes() {
  const { currentUser } = useApp();
  return (
    <Routes>
      <Route path="/login" element={currentUser ? <Navigate to={currentUser.role === 'admin' ? '/admin/dashboard' : '/student/dashboard'} /> : <Login />} />

      {/* Student routes */}
      <Route path="/student/dashboard" element={<ProtectedLayout role="student"><StudentDashboard /></ProtectedLayout>} />
      <Route path="/student/request" element={<ProtectedLayout role="student"><CertificateRequest /></ProtectedLayout>} />
      <Route path="/student/my-requests" element={<ProtectedLayout role="student"><MyRequests /></ProtectedLayout>} />
      <Route path="/student/id-card" element={<ProtectedLayout role="student"><StudentIDCard /></ProtectedLayout>} />
      <Route path="/student/notifications" element={<ProtectedLayout role="student"><Notifications /></ProtectedLayout>} />

      {/* Admin routes */}
      <Route path="/admin/dashboard" element={<ProtectedLayout role="admin"><AdminDashboard /></ProtectedLayout>} />
      <Route path="/admin/requests" element={<ProtectedLayout role="admin"><ManageRequests /></ProtectedLayout>} />
      <Route path="/admin/students" element={<ProtectedLayout role="admin"><Students /></ProtectedLayout>} />
      <Route path="/admin/id-cards" element={<ProtectedLayout role="admin"><IDCardGenerator /></ProtectedLayout>} />
      <Route path="/admin/reports" element={<ProtectedLayout role="admin"><Reports /></ProtectedLayout>} />

      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AppProvider>
  );
}
