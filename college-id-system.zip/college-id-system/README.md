# 🎓 College ID Card & Certificate Issuance System

A full-featured React web portal for managing student ID cards and certificate requests.

## 📁 Project Structure

```
college-id-system/
├── public/
│   └── index.html
├── src/
│   ├── context/
│   │   └── AppContext.jsx      ← Global state (students, requests, notifications)
│   ├── components/
│   │   └── Sidebar.jsx         ← Navigation sidebar
│   ├── pages/
│   │   ├── Login.jsx
│   │   ├── student/
│   │   │   ├── StudentDashboard.jsx
│   │   │   ├── CertificateRequest.jsx
│   │   │   ├── MyRequests.jsx
│   │   │   ├── StudentIDCard.jsx
│   │   │   └── Notifications.jsx
│   │   └── admin/
│   │       ├── AdminDashboard.jsx
│   │       ├── ManageRequests.jsx
│   │       ├── Students.jsx
│   │       ├── IDCardGenerator.jsx
│   │       └── Reports.jsx
│   ├── App.jsx                 ← Routing
│   ├── index.js
│   └── index.css               ← Global styles
└── package.json
```

## 🚀 Setup & Run

### Step 1 — Install Node.js
Download and install Node.js from https://nodejs.org (v16 or later)

### Step 2 — Open in VS Code
1. Open VS Code
2. Open this folder: File → Open Folder → select `college-id-system`

### Step 3 — Open Terminal in VS Code
Press `Ctrl + `` ` (backtick) to open the integrated terminal

### Step 4 — Install dependencies
```bash
npm install
```
Wait for all packages to download (~1-2 minutes)

### Step 5 — Start the app
```bash
npm start
```
The app will open automatically at http://localhost:3000

---

## 🔑 Login Credentials

| Role    | Username | Password   |
|---------|----------|------------|
| Student | sandeep  | student123 |
| Student | harsha   | student123 |
| Student | purna    | student123 |
| Admin   | admin    | admin123   |

---

## ✅ Features

### Student Portal
- Dashboard with request stats and quick actions
- Submit requests: Bonafide, NOC, Experience Letter, Replacement ID
- Track request status with approval workflow steps
- View digital ID card & print
- Notifications for approvals/rejections

### Admin Portal
- Dashboard with charts (BarChart, PieChart via Recharts)
- Manage all requests: Approve / Reject / Move through workflow
- Student CRUD (Add, Edit, Delete)
- ID Card Generator for any student
- Reports with CSV export (requests + students)

---

## 🛠 Tech Stack
- **React 18** + React Router v6
- **Context API** + LocalStorage (state persistence)
- **Recharts** (charts & graphs)
- **CSS Variables** (custom theming)
- No backend required — all data in localStorage

---

## 📦 Team Members
| Name            | Roll No     | Module                          |
|-----------------|-------------|---------------------------------|
| Sandeep Bangaru | 2520030523  | Certificate Form & Type Select  |
| Harsha Vardhan  | 2520090180  | Approval Flow & Status Track    |
| Purna Chandar   | 2520090188  | PDF Generate, Admin, Export     |
